import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CategoriesListService } from '../shared/categories-list.service';

@Component({
  selector: 'app-recipe-details',
  templateUrl: './recipe-details.component.html',
  styleUrls: ['./recipe-details.component.css']
})
export class RecipeDetailsComponent implements OnInit {
  categoriesList = [];
  itemId: any;
  constructor(private route: ActivatedRoute, private categoriesListService: CategoriesListService ) { }

  ngOnInit() {
   
  //   this.sub = this.route.params.subscribe(params => {
  //     this.id = params['idMeal'];
  // });
  // @localStorage
  this.itemId =JSON.parse(localStorage.getItem("id"));
  this.categoriesList.push(this.itemId);

  // this.categoriesListService.getRecipeDetails(this.itemId.idMeal).subscribe(data =>{
  //   console.log(data);
  //   this.categoriesList = data.meals;
  //   console.log(this.categoriesList);
  // });
  }
  ngOnDestroy() {
    // this.sub.unsubscribe();
  }

}
